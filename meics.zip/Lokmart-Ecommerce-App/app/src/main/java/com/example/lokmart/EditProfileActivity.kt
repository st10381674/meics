package com.example.lokmart

import android.app.Activity
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import de.hdodenhof.circleimageview.CircleImageView // optional if using circular profile images
import java.io.InputStream

class EditProfileActivity : AppCompatActivity() {

    private lateinit var toolbar: Toolbar
    private lateinit var imgProfileEdit: ImageView
    private lateinit var btnChangeImage: ImageButton
    private lateinit var etFullName: EditText
    private lateinit var etEmail: EditText
    private lateinit var etPhone: EditText
    private lateinit var etPassword: EditText
    private lateinit var btnSaveChanges: Button

    private val PICK_IMAGE_REQUEST = 100
    private var selectedImageUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_profile) // change to your actual XML filename

        // Initialize views
        toolbar = findViewById(R.id.editProfileToolbar)
        imgProfileEdit = findViewById(R.id.imgProfileEdit)
        btnChangeImage = findViewById(R.id.btnChangeImage)
        etFullName = findViewById(R.id.etFullName)
        etEmail = findViewById(R.id.etEmail)
        etPhone = findViewById(R.id.etPhone)
        etPassword = findViewById(R.id.etPassword)
        btnSaveChanges = findViewById(R.id.btnSaveChanges)

        // Toolbar navigation
        toolbar.setNavigationOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }

        // Load current user data (mock for now)
        loadUserData()

        // Handle profile picture change
        btnChangeImage.setOnClickListener {
            openGallery()
        }

        // Handle save changes
        btnSaveChanges.setOnClickListener {
            saveProfileChanges()
        }
    }

    private fun loadUserData() {
        // Mock data (replace with real user data from DB or SharedPreferences)
        etFullName.setText("John Doe")
        etEmail.setText("john.doe@example.com")
        etPhone.setText("0781234567")
    }

    private fun openGallery() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        startActivityForResult(intent, PICK_IMAGE_REQUEST)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK) {
            selectedImageUri = data?.data
            try {
                val inputStream: InputStream? = selectedImageUri?.let {
                    contentResolver.openInputStream(it)
                }
                val bitmap = BitmapFactory.decodeStream(inputStream)
                imgProfileEdit.setImageBitmap(bitmap)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun saveProfileChanges() {
        val name = etFullName.text.toString().trim()
        val email = etEmail.text.toString().trim()
        val phone = etPhone.text.toString().trim()
        val password = etPassword.text.toString().trim()

        if (name.isEmpty() || email.isEmpty() || phone.isEmpty()) {
            Toast.makeText(this, "Please fill in all required fields", Toast.LENGTH_SHORT).show()
            return
        }

        // Example of data saving (replace with actual DB or API save)
        Toast.makeText(
            this,
            "Profile updated successfully!\nName: $name\nEmail: $email\nPhone: $phone",
            Toast.LENGTH_LONG
        ).show()

        // You could also save to SharedPreferences here
        // val prefs = getSharedPreferences("UserProfile", MODE_PRIVATE)
        // prefs.edit().apply {
        //     putString("name", name)
        //     putString("email", email)
        //     putString("phone", phone)
        //     apply()
        // }

        finish() // Go back to previous page
    }
}
