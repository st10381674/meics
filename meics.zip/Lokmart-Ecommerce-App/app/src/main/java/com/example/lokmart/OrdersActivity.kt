package com.example.lokmart

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class OrdersActivity : AppCompatActivity() {

    private lateinit var toolbar: Toolbar
    private lateinit var ordersRecyclerView: RecyclerView
    private lateinit var tvNoOrders: TextView

    // Sample orders data
    private val ordersList = mutableListOf<Order>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_orders) // Replace with your XML file name

        // Toolbar
        toolbar = findViewById(R.id.ordersToolbar)
        toolbar.setNavigationOnClickListener { onBackPressedDispatcher.onBackPressed() }

        // Views
        ordersRecyclerView = findViewById(R.id.ordersRecyclerView)
        tvNoOrders = findViewById(R.id.tvNoOrders)

        // Setup RecyclerView
        ordersRecyclerView.layoutManager = LinearLayoutManager(this)
        val adapter = OrdersAdapter(ordersList)
        ordersRecyclerView.adapter = adapter

        // Load Orders (example)
        loadOrders()
        adapter.notifyDataSetChanged()

        // Show empty state if no orders
        tvNoOrders.visibility = if (ordersList.isEmpty()) View.VISIBLE else View.GONE
        ordersRecyclerView.visibility = if (ordersList.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun loadOrders() {
        // TODO: Replace with real data fetching
        // Example:
        ordersList.add(Order("001", "Pending", 149.99))
        ordersList.add(Order("002", "Shipped", 299.49))
        ordersList.add(Order("003", "Delivered", 89.99))
    }
}

// Simple data class for Order
data class Order(
    val orderId: String,
    val status: String,
    val total: Double
)

// Adapter
class OrdersAdapter(private val orders: List<Order>) :
    RecyclerView.Adapter<OrdersAdapter.OrderViewHolder>() {

    inner class OrderViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvOrderId: TextView = itemView.findViewById(R.id.tvOrderId)
        val tvStatus: TextView = itemView.findViewById(R.id.tvOrderStatus)
        val tvTotal: TextView = itemView.findViewById(R.id.tvOrderTotal)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): OrderViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_order, parent, false) // Create item_order.xml layout
        return OrderViewHolder(view)
    }

    override fun onBindViewHolder(holder: OrderViewHolder, position: Int) {
        val order = orders[position]
        holder.tvOrderId.text = "Order #${order.orderId}"
        holder.tvStatus.text = "Status: ${order.status}"
        holder.tvTotal.text = "Total: R${order.total}"
    }

    override fun getItemCount(): Int = orders.size
}
