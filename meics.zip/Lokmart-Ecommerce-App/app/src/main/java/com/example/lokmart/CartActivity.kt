package com.example.lokmart


import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class CartActivity : AppCompatActivity() {

    private lateinit var rvCartItems: RecyclerView
    private lateinit var tvTotalAmount: TextView
    private lateinit var btnCheckout: Button

    private lateinit var cartAdapter: CartAdapter
    private val cartItems = mutableListOf<CartItem>() // List of items in the cart

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cart) // Use your XML file name here

        // Initialize views
        rvCartItems = findViewById(R.id.rvCartItems)
        tvTotalAmount = findViewById(R.id.tvTotalAmount)
        btnCheckout = findViewById(R.id.btnCheckout)

        // RecyclerView setup
        rvCartItems.layoutManager = LinearLayoutManager(this)
        cartAdapter = CartAdapter(cartItems) { updateTotal() }
        rvCartItems.adapter = cartAdapter

        // Load sample data (you can replace with real data)
        loadCartItems()

        // Checkout button
        btnCheckout.setOnClickListener {
            Toast.makeText(this, "Proceeding to checkout...", Toast.LENGTH_SHORT).show()
            // Here you could start CheckoutActivity or payment process
        }
    }

    private fun loadCartItems() {
        cartItems.add(CartItem("Cement (50kg)", 2, 95.0))
        cartItems.add(CartItem("Paint (20L)", 1, 320.0))
        cartItems.add(CartItem("Bricks (1000)", 1, 850.0))
        cartItems.add(CartItem("Wheelbarrow", 1, 650.0))
        cartAdapter.notifyDataSetChanged()
        updateTotal()
    }

    private fun updateTotal() {
        val total = cartItems.sumOf { it.price * it.quantity }
        tvTotalAmount.text = "Total: R${String.format("%.2f", total)}"
    }
}
