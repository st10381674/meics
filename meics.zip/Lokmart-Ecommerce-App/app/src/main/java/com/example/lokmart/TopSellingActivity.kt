package com.example.lokmart

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class TopSellingActivity : AppCompatActivity() {

    private lateinit var toolbar: Toolbar
    private lateinit var topSellingRecyclerView: RecyclerView
    private lateinit var topSellingAdapter: TopSellingAdapter
    private val topSellingList = mutableListOf<TopSellingItem>() // Replace with your data model

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_top_selling) // Replace with your XML name

        // Toolbar
        toolbar = findViewById(R.id.topSellingToolbar)
        toolbar.setNavigationOnClickListener { onBackPressedDispatcher.onBackPressed() }

        // RecyclerView
        topSellingRecyclerView = findViewById(R.id.topSellingRecyclerView)
        topSellingRecyclerView.layoutManager = LinearLayoutManager(this)

        // Initialize adapter
        topSellingAdapter = TopSellingAdapter(topSellingList)
        topSellingRecyclerView.adapter = topSellingAdapter

        // Load sample data
        loadTopSellingItems()
    }

    private fun loadTopSellingItems() {
        // Sample data
        topSellingList.add(TopSellingItem("Cement", 150))
        topSellingList.add(TopSellingItem("Bricks", 300))
        topSellingList.add(TopSellingItem("Paint", 120))
        topSellingList.add(TopSellingItem("Steel Rods", 80))

        topSellingAdapter.notifyDataSetChanged()
    }
}
