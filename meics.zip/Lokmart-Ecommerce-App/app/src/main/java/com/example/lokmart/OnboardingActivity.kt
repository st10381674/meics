package com.example.lokmart

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.ImageView
import android.widget.TextView

class OnboardingActivity : AppCompatActivity() {

    private lateinit var backgroundImage: ImageView
    private lateinit var mainImage: ImageView
    private lateinit var titleText: TextView
    private lateinit var descriptionText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_onboarding)

        // Initialize views
        backgroundImage = findViewById(R.id.background)
        mainImage = findViewById(R.id.image)
        titleText = findViewById(R.id.title)
        descriptionText = findViewById(R.id.description)

        // Optional: set content dynamically
        backgroundImage.setImageResource(R.drawable.onboarding_background)
        mainImage.setImageResource(R.drawable.onboarding_image_0)
        titleText.text = "Welcome to LokMart!\nGrocery Application"
        descriptionText.text = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore."
    }
}
