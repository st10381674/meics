package com.example.lokmart.common

object Constants {

    const val HOST = ""
}