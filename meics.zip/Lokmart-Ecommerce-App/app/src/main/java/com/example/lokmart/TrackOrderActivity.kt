package com.example.lokmart


import android.graphics.drawable.Drawable
import android.os.Bundle
import android.widget.TextView
import android.widget.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.content.ContextCompat
import android.widget.LinearLayout

class TrackOrderActivity : AppCompatActivity() {

    private lateinit var toolbar: Toolbar
    private lateinit var tvExpectedDelivery: TextView

    // Step views
    private lateinit var stepPending: View
    private lateinit var stepShipped: View
    private lateinit var stepDelivered: View

    private lateinit var tvPending: TextView
    private lateinit var tvShipped: TextView
    private lateinit var tvDelivered: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_track_order) // Replace with your XML name

        // Toolbar
        toolbar = findViewById(R.id.trackingToolbar)
        toolbar.setNavigationOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }

        // Expected delivery
        tvExpectedDelivery = findViewById(R.id.tvExpectedDelivery)
        val expectedDate = intent.getStringExtra("expectedDate") ?: "30 Oct 2025"
        tvExpectedDelivery.text = "Expected Delivery: $expectedDate"

        // Steps
        val stepsContainer = findViewById<LinearLayout>(R.id.stepsContainer)
        // Access the step views dynamically (or assign IDs in XML if needed)
        stepPending = stepsContainer.getChildAt(0).findViewById(R.id.circle_pending)
        stepShipped = stepsContainer.getChildAt(2).findViewById(R.id.circle_in_progress)
        stepDelivered = stepsContainer.getChildAt(4).findViewById(R.id.circle_completed)

        tvPending = stepsContainer.getChildAt(0).findViewById(R.id.tvStep)
        tvShipped = stepsContainer.getChildAt(2).findViewById(R.id.tvStep)
        tvDelivered = stepsContainer.getChildAt(4).findViewById(R.id.tvStep)

        // Example: Update step statuses programmatically
        updateOrderProgress("Shipped")
    }

    private fun updateOrderProgress(currentStatus: String) {
        val completedDrawable: Drawable? = ContextCompat.getDrawable(this, R.drawable.circle_completed)
        val inProgressDrawable: Drawable? = ContextCompat.getDrawable(this, R.drawable.circle_in_progress)
        val pendingDrawable: Drawable? = ContextCompat.getDrawable(this, R.drawable.circle_pending)

        when (currentStatus.lowercase()) {
            "pending" -> {
                stepPending.background = inProgressDrawable
                stepShipped.background = pendingDrawable
                stepDelivered.background = pendingDrawable
            }
            "shipped" -> {
                stepPending.background = completedDrawable
                stepShipped.background = inProgressDrawable
                stepDelivered.background = pendingDrawable
            }
            "delivered" -> {
                stepPending.background = completedDrawable
                stepShipped.background = completedDrawable
                stepDelivered.background = inProgressDrawable
            }
        }

        Toast.makeText(this, "Order status updated: $currentStatus", Toast.LENGTH_SHORT).show()
    }
}
