package com.example.lokmart

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Switch
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import com.google.android.material.snackbar.Snackbar

class SettingsActivity : AppCompatActivity() {

    private lateinit var toolbar: Toolbar
    private lateinit var switchNotifications: Switch
    private lateinit var switchDarkMode: Switch
    private lateinit var btnLogout: Button

    private lateinit var layoutEditProfile: LinearLayout
    private lateinit var layoutChangePassword: LinearLayout
    private lateinit var layoutLanguage: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings) // Replace with your XML name

        // Toolbar
        toolbar = findViewById(R.id.settingsToolbar)
        toolbar.setNavigationOnClickListener { onBackPressedDispatcher.onBackPressed() }

        // Switches
        switchNotifications = findViewById(R.id.switchNotifications)
        switchDarkMode = findViewById(R.id.switchDarkMode)

        // Buttons
        btnLogout = findViewById(R.id.btnLogout)

        // Account Options
        layoutEditProfile = findViewById(R.id.editProfileLayout)
        layoutChangePassword = findViewById(R.id.changePasswordLayout)
        layoutLanguage = findViewById(R.id.languageLayout)

        // Click listeners for account options
        layoutEditProfile.setOnClickListener {
            // Navigate to EditProfileActivity
            startActivity(Intent(this, EditProfileActivity::class.java))
        }

        layoutChangePassword.setOnClickListener {
            // Navigate to ChangePasswordActivity
            startActivity(Intent(this, ChangePasswordActivity::class.java))
        }

        layoutLanguage.setOnClickListener {
            // Example: Show a Snackbar (or open language selection)
            Snackbar.make(it, "Language option clicked", Snackbar.LENGTH_SHORT).show()
        }

        // Switch listeners
        switchNotifications.setOnCheckedChangeListener { _, isChecked ->
            // Handle notifications toggle
            Snackbar.make(toolbar, "Notifications: ${if (isChecked) "On" else "Off"}", Snackbar.LENGTH_SHORT).show()
        }

        switchDarkMode.setOnCheckedChangeListener { _, isChecked ->
            // Handle dark mode toggle
            Snackbar.make(toolbar, "Dark Mode: ${if (isChecked) "Enabled" else "Disabled"}", Snackbar.LENGTH_SHORT).show()
        }

        // Logout button
        btnLogout.setOnClickListener {
            // Example: Navigate to LoginActivity and clear session
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }
}
