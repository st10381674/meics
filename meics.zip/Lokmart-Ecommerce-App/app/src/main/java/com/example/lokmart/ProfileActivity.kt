package com.example.lokmart

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView

class ProfileActivity : AppCompatActivity() {

    private lateinit var toolbar: Toolbar
    private lateinit var imgProfile: ImageView
    private lateinit var tvUserName: TextView
    private lateinit var tvUserEmail: TextView
    private lateinit var btnEditProfile: Button
    private lateinit var rvOrderHistory: RecyclerView

    // Sample order history
    private val orderHistoryList = mutableListOf<Order>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile) // Replace with your XML name

        // Toolbar
        toolbar = findViewById(R.id.profileToolbar)
        toolbar.setNavigationOnClickListener { onBackPressedDispatcher.onBackPressed() }

        // Views
        imgProfile = findViewById(R.id.imgProfile)
        tvUserName = findViewById(R.id.tvUserName)
        tvUserEmail = findViewById(R.id.tvUserEmail)
        btnEditProfile = findViewById(R.id.btnEditProfile)
        rvOrderHistory = findViewById(R.id.rvOrderHistory)

        // Set user info (replace with real data)
        tvUserName.text = "John Doe"
        tvUserEmail.text = "john@example.com"

        btnEditProfile.setOnClickListener {
            // Handle edit profile click
            // e.g., open EditProfileActivity
        }

        // Setup RecyclerView for order history
        rvOrderHistory.layoutManager = LinearLayoutManager(this)
        val adapter = OrdersAdapter(orderHistoryList)
        rvOrderHistory.adapter = adapter

        // Load sample order history
        loadOrderHistory()
        adapter.notifyDataSetChanged()
    }

    private fun loadOrderHistory() {
        // TODO: Replace with real data
        orderHistoryList.add(Order("001", "Delivered", 149.99))
        orderHistoryList.add(Order("002", "Shipped", 299.49))
        orderHistoryList.add(Order("003", "Pending", 89.99))
    }
}

// Reuse Order data class and OrdersAdapter from previous example
data class Order(
    val orderId: String,
    val status: String,
    val total: Double
)

class OrdersAdapter(private val orders: List<Order>) :
    RecyclerView.Adapter<OrdersAdapter.OrderViewHolder>() {

    inner class OrderViewHolder(itemView: android.view.View) :
        RecyclerView.ViewHolder(itemView) {
        val tvOrderId: TextView = itemView.findViewById(R.id.tvOrderId)
        val tvStatus: TextView = itemView.findViewById(R.id.tvOrderStatus)
        val tvTotal: TextView = itemView.findViewById(R.id.tvOrderTotal)
    }

    override fun onCreateViewHolder(parent: android.view.ViewGroup, viewType: Int): OrderViewHolder {
        val view = android.view.LayoutInflater.from(parent.context)
            .inflate(R.layout.item_order, parent, false) // Create item_order.xml layout
        return OrderViewHolder(view)
    }

    override fun onBindViewHolder(holder: OrderViewHolder, position: Int) {
        val order = orders[position]
        holder.tvOrderId.text = "Order #${order.orderId}"
        holder.tvStatus.text = "Status: ${order.status}"
        holder.tvTotal.text = "Total: R${order.total}"
    }

    override fun getItemCount(): Int = orders.size
}
