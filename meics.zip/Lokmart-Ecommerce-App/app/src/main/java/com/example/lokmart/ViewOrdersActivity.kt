package com.example.lokmart

import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar

class ViewOrdersActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view_orders)

        // Set up the toolbar
        val toolbar = findViewById<Toolbar>(R.id.ordersToolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener {
            finish() // Go back to previous page
        }

        // Find the buttons from the first example order card
        val btnViewOrder = findViewById<Button>(R.id.btnViewOrder)
        val btnApproveOrder = findViewById<Button>(R.id.btnApproveOrder)
        val btnCancelOrder = findViewById<Button>(R.id.btnCancelOrder)

        // Example click actions
        btnViewOrder?.setOnClickListener {
            Toast.makeText(this, "Viewing Order Details", Toast.LENGTH_SHORT).show()
            // startActivity(Intent(this, OrderDetailsActivity::class.java))
        }

        btnApproveOrder?.setOnClickListener {
            Toast.makeText(this, "Order Approved ✅", Toast.LENGTH_SHORT).show()
        }

        btnCancelOrder?.setOnClickListener {
            Toast.makeText(this, "Order Cancelled ❌", Toast.LENGTH_SHORT).show()
        }
    }
}
