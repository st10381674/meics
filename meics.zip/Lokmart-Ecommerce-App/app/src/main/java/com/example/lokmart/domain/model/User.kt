package com.example.lokmart.domain.model

data class User(
    val username:String
)
