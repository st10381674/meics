package com.example.lokmart

import android.app.DatePickerDialog
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import java.util.*

class ContactBookingActivity : AppCompatActivity() {

    private lateinit var toolbar: Toolbar
    private lateinit var etName: EditText
    private lateinit var etEmail: EditText
    private lateinit var etPhone: EditText
    private lateinit var spinnerService: Spinner
    private lateinit var etDate: EditText
    private lateinit var etDetails: EditText
    private lateinit var btnSubmitBooking: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_contact_booking) // replace with your XML name

        // Initialize views
        toolbar = findViewById(R.id.contactToolbar)
        etName = findViewById(R.id.etName)
        etEmail = findViewById(R.id.etEmail)
        etPhone = findViewById(R.id.etPhone)
        spinnerService = findViewById(R.id.spinnerService)
        etDate = findViewById(R.id.etDate)
        etDetails = findViewById(R.id.etDetails)
        btnSubmitBooking = findViewById(R.id.btnSubmitBooking)

        // Toolbar navigation
        toolbar.setNavigationOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }

        // Spinner setup (list of services)
        val services = listOf(
            "Select a Service",
            "Building Construction",
            "Home Renovation",
            "Roof Repair",
            "Plumbing",
            "Electrical Installation",
            "Painting",
            "Flooring & Tiling"
        )

        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            services
        )
        spinnerService.adapter = adapter

        // Date picker for preferred date
        etDate.setOnClickListener {
            val calendar = Calendar.getInstance()
            val year = calendar.get(Calendar.YEAR)
            val month = calendar.get(Calendar.MONTH)
            val day = calendar.get(Calendar.DAY_OF_MONTH)

            val datePicker = DatePickerDialog(
                this,
                { _, selectedYear, selectedMonth, selectedDay ->
                    etDate.setText("$selectedDay/${selectedMonth + 1}/$selectedYear")
                },
                year, month, day
            )
            datePicker.show()
        }

        // Handle form submission
        btnSubmitBooking.setOnClickListener {
            val name = etName.text.toString().trim()
            val email = etEmail.text.toString().trim()
            val phone = etPhone.text.toString().trim()
            val selectedService = spinnerService.selectedItem.toString()
            val date = etDate.text.toString().trim()
            val details = etDetails.text.toString().trim()

            // Validation
            if (name.isEmpty() || email.isEmpty() || phone.isEmpty() || date.isEmpty() || selectedService == "Select a Service") {
                Toast.makeText(this, "Please fill in all required fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Simulated booking confirmation
            val summary = """
                ✅ Booking Request Sent Successfully!

                Name: $name
                Email: $email
                Phone: $phone
                Service: $selectedService
                Preferred Date: $date
                Details: $details
            """.trimIndent()

            val dialog = android.app.AlertDialog.Builder(this)
                .setTitle("Booking Confirmation")
                .setMessage(summary)
                .setPositiveButton("OK") { d, _ -> d.dismiss() }
                .create()
            dialog.show()

            // Clear fields after submission
            etName.text.clear()
            etEmail.text.clear()
            etPhone.text.clear()
            etDate.text.clear()
            etDetails.text.clear()
            spinnerService.setSelection(0)
        }
    }
}
