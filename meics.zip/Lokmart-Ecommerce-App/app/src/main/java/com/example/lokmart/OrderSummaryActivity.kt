package com.example.lokmart


import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar

class OrderSummaryActivity : AppCompatActivity() {

    private lateinit var toolbar: Toolbar
    private lateinit var tvOrderId: TextView
    private lateinit var tvOrderDate: TextView
    private lateinit var tvOrderItems: TextView
    private lateinit var tvOrderTotal: TextView
    private lateinit var tvOrderStatus: TextView
    private lateinit var btnTrackOrder: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_order_summary) // Use your actual XML name

        // Initialize views
        toolbar = findViewById(R.id.orderSummaryToolbar)
        tvOrderId = findViewById(R.id.tvOrderId)
        tvOrderDate = findViewById(R.id.tvOrderDate)
        tvOrderItems = findViewById(R.id.tvOrderItems)
        tvOrderTotal = findViewById(R.id.tvOrderTotal)
        tvOrderStatus = findViewById(R.id.tvOrderStatus)
        btnTrackOrder = findViewById(R.id.btnTrackOrder)

        // Handle back button in toolbar
        toolbar.setNavigationOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }

        // Load order details (you can pass these via Intent)
        loadOrderDetails()

        // Track order button click
        btnTrackOrder.setOnClickListener {
            Toast.makeText(this, "Tracking order...", Toast.LENGTH_SHORT).show()

            // Example navigation to tracking screen (optional)
            // val intent = Intent(this, TrackOrderActivity::class.java)
            // intent.putExtra("orderId", tvOrderId.text.toString())
            // startActivity(intent)
        }
    }

    private fun loadOrderDetails() {
        // Mock data - you can replace this with real data from Intent or Database
        val orderId = intent.getStringExtra("orderId") ?: "123456"
        val orderDate = intent.getStringExtra("orderDate") ?: "24/10/2025"
        val orderItems = intent.getStringExtra("orderItems") ?: "Cement, Bricks, Paint"
        val orderTotal = intent.getStringExtra("orderTotal") ?: "R1,299.99"
        val orderStatus = intent.getStringExtra("orderStatus") ?: "Pending"

        // Set data to TextViews
        tvOrderId.text = "Order ID: $orderId"
        tvOrderDate.text = "Date: $orderDate"
        tvOrderItems.text = "Items: $orderItems"
        tvOrderTotal.text = "Total: $orderTotal"
        tvOrderStatus.text = "Status: $orderStatus"

        // Change status color dynamically
        when (orderStatus.lowercase()) {
            "pending" -> tvOrderStatus.setTextColor(getColor(R.color.orange))
            "completed" -> tvOrderStatus.setTextColor(getColor(R.color.green))
            "cancelled" -> tvOrderStatus.setTextColor(getColor(R.color.red))
        }
    }
}
