package com.example.lokmart


import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class CartItemViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
    private val tvCartItemName: TextView = itemView.findViewById(R.id.tvCartItemName)
    private val tvCartItemPrice: TextView = itemView.findViewById(R.id.tvCartItemPrice)
    private val tvQuantity: TextView = itemView.findViewById(R.id.tvQuantity)
    private val btnIncrease: Button = itemView.findViewById(R.id.btnIncrease)
    private val btnDecrease: Button = itemView.findViewById(R.id.btnDecrease)

    fun bind(item: CartItem) {
        tvCartItemName.text = item.name
        tvCartItemPrice.text = "$${item.price}"
        tvQuantity.text = item.quantity.toString()

        btnIncrease.setOnClickListener {
            item.quantity++
            tvQuantity.text = item.quantity.toString()
            onQuantityChanged(item)
        }

        btnDecrease.setOnClickListener {
            if (item.quantity > 1) {
                item.quantity--
                tvQuantity.text = item.quantity.toString()
                onQuantityChanged(item)
            }
        }
    }

    // Optional callback to update total cart price
    var onQuantityChanged: (CartItem) -> Unit = {}
}
