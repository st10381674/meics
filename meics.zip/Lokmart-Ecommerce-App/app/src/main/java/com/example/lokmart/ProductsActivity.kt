package com.example.lokmart


import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class ProductsActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var btnAddProduct: Button
    private lateinit var btnEditProduct: Button
    private lateinit var btnDeleteProduct: Button
    private lateinit var adapter: ProductAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_products)

        // Toolbar setup
        val toolbar = findViewById<Toolbar>(R.id.productsToolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener { finish() }

        // Initialize views
        recyclerView = findViewById(R.id.productsRecyclerView)
        btnAddProduct = findViewById(R.id.btnAddProduct)
        btnEditProduct = findViewById(R.id.btnEditProduct)
        btnDeleteProduct = findViewById(R.id.btnDeleteProduct)

        // Example product list
        val products = listOf(
            Product("Cement 50kg", "R120.00", R.drawable.cement),
            Product("Bricks (per 1000)", "R1500.00", R.drawable.bricks),
            Product("Roof Sheets", "R250.00", R.drawable.roofsheet),
            Product("Paint 20L", "R890.00", R.drawable.paint),
            Product("Wheelbarrow", "R650.00", R.drawable.wheelbarrow),
            Product("PVC Pipes", "R200.00", R.drawable.pvcpipes),
            Product("Sand (per ton)", "R350.00", R.drawable.sand),
            Product("Concrete Mixer", "R5500.00", R.drawable.mixer)
        )

        // RecyclerView setup
        adapter = ProductAdapter(products)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        // Button actions
        btnAddProduct.setOnClickListener {
            Toast.makeText(this, "Add Product clicked", Toast.LENGTH_SHORT).show()
            // startActivity(Intent(this, AddProductActivity::class.java))
        }

        btnEditProduct.setOnClickListener {
            Toast.makeText(this, "Edit Product clicked", Toast.LENGTH_SHORT).show()
        }

        btnDeleteProduct.setOnClickListener {
            Toast.makeText(this, "Delete Product clicked", Toast.LENGTH_SHORT).show()
        }
    }
}
