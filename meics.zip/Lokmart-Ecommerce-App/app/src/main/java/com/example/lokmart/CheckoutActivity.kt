package com.example.lokmart

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar

class CheckoutActivity : AppCompatActivity() {

    private lateinit var toolbar: Toolbar
    private lateinit var etFullName: EditText
    private lateinit var etAddress: EditText
    private lateinit var etCity: EditText
    private lateinit var etPostalCode: EditText
    private lateinit var etPhone: EditText
    private lateinit var rgPaymentMethod: RadioGroup
    private lateinit var rbCreditCard: RadioButton
    private lateinit var rbPayPal: RadioButton
    private lateinit var rbCOD: RadioButton
    private lateinit var tvOrderSummary: TextView
    private lateinit var btnPlaceOrder: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_checkout) // replace with your actual XML filename

        // Initialize views
        toolbar = findViewById(R.id.checkoutToolbar)
        etFullName = findViewById(R.id.etFullName)
        etAddress = findViewById(R.id.etAddress)
        etCity = findViewById(R.id.etCity)
        etPostalCode = findViewById(R.id.etPostalCode)
        etPhone = findViewById(R.id.etPhone)
        rgPaymentMethod = findViewById(R.id.rgPaymentMethod)
        rbCreditCard = findViewById(R.id.rbCreditCard)
        rbPayPal = findViewById(R.id.rbPayPal)
        rbCOD = findViewById(R.id.rbCOD)
        tvOrderSummary = findViewById(R.id.tvOrderSummary)
        btnPlaceOrder = findViewById(R.id.btnPlaceOrder)

        // Toolbar back navigation
        toolbar.setNavigationOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }

        // Handle place order button click
        btnPlaceOrder.setOnClickListener {
            val fullName = etFullName.text.toString().trim()
            val address = etAddress.text.toString().trim()
            val city = etCity.text.toString().trim()
            val postalCode = etPostalCode.text.toString().trim()
            val phone = etPhone.text.toString().trim()

            // Validate user input
            if (fullName.isEmpty() || address.isEmpty() || city.isEmpty() || postalCode.isEmpty() || phone.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Check payment method selection
            val selectedPaymentId = rgPaymentMethod.checkedRadioButtonId
            if (selectedPaymentId == -1) {
                Toast.makeText(this, "Please select a payment method", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Determine which payment option is selected
            val paymentMethod = when (selectedPaymentId) {
                R.id.rbCreditCard -> "Credit Card"
                R.id.rbPayPal -> "PayPal"
                R.id.rbCOD -> "Cash on Delivery"
                else -> ""
            }

            // Simulate placing order
            val orderSummary = """
                ✅ Order Placed Successfully!
                
                Name: $fullName
                Address: $address, $city
                Postal Code: $postalCode
                Phone: $phone
                Payment Method: $paymentMethod
                
                ${tvOrderSummary.text}
            """.trimIndent()

            // Show confirmation message
            Toast.makeText(this, "Order placed successfully!", Toast.LENGTH_LONG).show()

            // Optionally show order summary in a dialog
            val dialog = android.app.AlertDialog.Builder(this)
                .setTitle("Order Confirmation")
                .setMessage(orderSummary)
                .setPositiveButton("OK") { d, _ -> d.dismiss() }
                .create()
            dialog.show()

            // Clear all fields after successful order
            etFullName.text.clear()
            etAddress.text.clear()
            etCity.text.clear()
            etPostalCode.text.clear()
            etPhone.text.clear()
            rgPaymentMethod.clearCheck()
        }
    }
}
