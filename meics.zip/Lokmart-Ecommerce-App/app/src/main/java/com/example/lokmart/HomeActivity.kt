package com.example.lokmart



import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomnavigation.BottomNavigationView

class HomeActivity : AppCompatActivity() {

    private lateinit var searchEditText: EditText
    private lateinit var bottomNavigation: BottomNavigationView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home) // Replace with your XML file name

        searchEditText = findViewById(R.id.searchEditText) // optional: if you give id to EditText
        bottomNavigation = findViewById(R.id.bottomNavigation)

        // Category click listeners
        val categoryMachinery = findViewById<LinearLayout>(R.id.category1)
        val categoryTools = findViewById<LinearLayout>(R.id.category2)
        val categoryMaterials = findViewById<LinearLayout>(R.id.category3)
        val categorySafety = findViewById<LinearLayout>(R.id.category4)

        categoryMachinery.setOnClickListener { showCategoryToast("Machinery") }
        categoryTools.setOnClickListener { showCategoryToast("Tools") }
        categoryMaterials.setOnClickListener { showCategoryToast("Materials") }
        categorySafety.setOnClickListener { showCategoryToast("Safety") }

        // Product "Add to Cart" buttons
        val productButtons = listOf(
            R.id.btnProduct1, R.id.btnProduct2, R.id.btnProduct3, R.id.btnProduct4,
            R.id.btnProduct5, R.id.btnProduct6, R.id.btnProduct7, R.id.btnProduct8,
            R.id.btnProduct9, R.id.btnProduct10, R.id.btnProduct11, R.id.btnProduct12
        )

        productButtons.forEachIndexed { index, btnId ->
            findViewById<Button>(btnId).setOnClickListener {
                Toast.makeText(this, "Added Product ${index + 1} to cart", Toast.LENGTH_SHORT).show()
            }
        }

        // Bottom Navigation item selection
        bottomNavigation.setOnItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.nav_home -> {
                    Toast.makeText(this, "Home selected", Toast.LENGTH_SHORT).show()
                    true
                }
                R.id.nav_cart -> {
                    Toast.makeText(this, "Cart selected", Toast.LENGTH_SHORT).show()
                    true
                }
                R.id.nav_profile -> {
                    Toast.makeText(this, "Profile selected", Toast.LENGTH_SHORT).show()
                    true
                }
                else -> false
            }
        }
    }

    private fun showCategoryToast(category: String) {
        Toast.makeText(this, "Selected $category category", Toast.LENGTH_SHORT).show()
    }
}
