package com.example.lokmart

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class StockActivity : AppCompatActivity() {

    private lateinit var toolbar: Toolbar
    private lateinit var stockRecyclerView: RecyclerView
    private lateinit var stockAdapter: StockAdapter
    private val stockList = mutableListOf<StockItem>() // Replace with your data model

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_stock) // Replace with your XML name

        // Toolbar
        toolbar = findViewById(R.id.stockToolbar)
        toolbar.setNavigationOnClickListener { onBackPressedDispatcher.onBackPressed() }

        // RecyclerView
        stockRecyclerView = findViewById(R.id.stockRecyclerView)
        stockRecyclerView.layoutManager = LinearLayoutManager(this)

        // Initialize adapter with sample data
        stockAdapter = StockAdapter(stockList)
        stockRecyclerView.adapter = stockAdapter

        // Load stock data (replace with real data)
        loadStockData()
    }

    private fun loadStockData() {
        // Sample data
        stockList.add(StockItem("Cement", 50))
        stockList.add(StockItem("Bricks", 200))
        stockList.add(StockItem("Paint", 75))

        stockAdapter.notifyDataSetChanged()
    }
}
