package com.example.Lokmart

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomnavigation.BottomNavigationView
import android.widget.Toast

class AdminDashboardActivity : AppCompatActivity() {

    private lateinit var ordersCount: TextView
    private lateinit var productsCount: TextView
    private lateinit var stockCount: TextView
    private lateinit var topSellingCount: TextView

    private lateinit var btnViewOrders: Button
    private lateinit var btnManageProducts: Button
    private lateinit var btnManageStock: Button
    private lateinit var btnManageTopSelling: Button

    private lateinit var bottomNav: BottomNavigationView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin_dashboard)

        // Initialize views
        ordersCount = findViewById(R.id.ordersCount)
        productsCount = findViewById(R.id.productsCount)
        stockCount = findViewById(R.id.stockCount)
        topSellingCount = findViewById(R.id.topSellingCount)

        btnViewOrders = findViewById(R.id.btnViewOrders)
        btnManageProducts = findViewById(R.id.btnManageProducts)
        btnManageStock = findViewById(R.id.btnManageStock)
        btnManageTopSelling = findViewById(R.id.btnManageTopSelling)

        bottomNav = findViewById(R.id.bottomNav)

        // Example values - these could come from a database or API
        ordersCount.text = "120"
        productsCount.text = "80"
        stockCount.text = "45"
        topSellingCount.text = "15"

        // Button click listeners
        btnViewOrders.setOnClickListener {
            startActivity(Intent(this, ViewOrdersActivity::class.java))
        }

        btnManageProducts.setOnClickListener {
            startActivity(Intent(this, ManageProductsActivity::class.java))
        }

        btnManageStock.setOnClickListener {
            startActivity(Intent(this, ManageStockActivity::class.java))
        }

        btnManageTopSelling.setOnClickListener {
            startActivity(Intent(this, TopSellingActivity::class.java))
        }

        // Bottom navigation
        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    Toast.makeText(this, "Dashboard", Toast.LENGTH_SHORT).show()
                    true
                }
                R.id.nav_profile -> {
                    startActivity(Intent(this, AdminProfileActivity::class.java))
                    true
                }
                R.id.nav_settings -> {
                    startActivity(Intent(this, AdminSettingsActivity::class.java))
                    true
                }
                else -> false
            }
        }
    }
}
